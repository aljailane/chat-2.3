<?php
/*
Project: PBNL Forum v2.3

Coded By: Oyebamiji Akorede (Harkorede)

Facebook: http://facebook.com/harkorede94

Email: (harkorede01@gmail.com)

CellPhone +2348029828364

Twitter: @harkorede94

WebSite: http://naijamobile.in
*/
include('monit.php');
echo "<br>";
echo"<div class='b_head'>BAN / UNBAN MENU</div><br/><div class='user-info'><ul><li><a href='unbanuser.php'>Unban users</a></li><li><a href='banuser.php'>Ban User</li>";
echo"<div class='link_button'><a href='../member/index.php'>Back to Main Site</a></div></div>";
include "../footer.php";
?>
